# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class WoolworthsIcedTeasItem(scrapy.Item):


        product_name = scrapy.Field()
        breadcrumb = scrapy.Field()
        product_price = scrapy.Field()
        cup_measure = scrapy.Field()
        # Add more fields as needed (e.g., brand, size, etc.)


