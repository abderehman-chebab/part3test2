# This package will contain the spiders of your Scrapy project
#
# Please refer to the documentation for information on how to create and manage
# your spiders.
import scrapy
import json
from woolworths_iced_teas.items import WoolworthsIcedTeasItem
class IcedTeaSpider(scrapy.Spider):
    name = 'iced_tea_spider'

    def start_requests(self):
        base_url = "https://www.woolworths.com.au/apis/ui/browse/category"
        payload = {
            "categoryId": "1_9573995",
            "pageNumber": 1,
            "pageSize": 24,
            "sortType":"NameAsc",
            "storeId": 1005  # replace 1005 with store ID if necessary
        }
        yield scrapy.Request(url=base_url, method='POST', body=json.dumps(payload), headers={'Content-Type': 'application/json'}, callback=self.parse)

    def parse(self, response):
        data = json.loads(response.body)
        for product in data.get('Products', []):
            item = IcedTeaItem()
            item['product_name'] = product.get('Name', '')
            item['product_price'] = product.get('Price', '')
            item['cup_measure'] = product.get('CupMeasure', '')
            # Extract other product details here

            # Construct breadcrumb
            category_names = [category['Name'] for category in product.get('Categories', [])]
            item['breadcrumb'] = ["Home"] + category_names

            yield item

        # Check for next page
        if 'NextPage' in data.get('Links', []):
            next_page_url = data.get('Links', [])['NextPage']
            yield scrapy.Request(url=next_page_url, callback=self.parse)
