# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface




from itemadapter import ItemAdapter
import csv
import logging




class WoolworthsIcedTeasPipeline:
    def process_item(self, item, spider):
        def open_spider(self, spider):
            self.file = open("iced_teas_detailed.csv", "w", newline="", encoding="utf-8")
            self.fieldnames = [
                "product_name",
                "breadcrumb",
                "product_price",
                "cup_measure",
            ]  # Add more fields as needed
            self.writer = csv.DictWriter(self.file, fieldnames=self.fieldnames)
            self.writer.writeheader()

            self.logger = logging.getLogger(__name__)

        def process_item(self, item, spider):
            adapter = ItemAdapter(item)

            # Cleaning and Normalizing Data
            for field in self.fieldnames:
                value = adapter.get(field)

                # Handle missing values
                if value is None:
                    adapter[field] = ""  # Replace with empty string or another default value

                # Breadcrumb handling
                if field == "breadcrumb" and isinstance(value, list):
                    adapter[field] = " > ".join(value)

                # Price handling
                if field == "product_price":
                    try:
                        adapter[field] = float(value.replace("$", ""))
                    except (ValueError, TypeError):
                        self.logger.warning(f"Unable to convert price to float: {value}")
                        adapter[field] = ""

            self.writer.writerow(adapter.asdict())
            return item

        def close_spider(self, spider):
            self.file.close()

