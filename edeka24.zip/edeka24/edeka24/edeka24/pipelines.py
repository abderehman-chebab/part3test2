# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter


from itemadapter import ItemAdapter
import csv

class Edeka24Pipeline:
    def open_spider(self, spider):
        self.file = open("edeka24_products.csv", "w", newline="", encoding="utf-8")
        self.writer = csv.writer(self.file)
        self.writer.writerow(["Product Name", "Breadcrumb", "Price", "Image URL"])

    def process_item(self, item, spider):
        breadcrumb_str = " > ".join(item["breadcrumb"])  # Convert breadcrumb list to string
        self.writer.writerow([item["product_name"], breadcrumb_str, item["price"], item["image_url"]])
        return item

    def close_spider(self, spider):
        self.file.close()
