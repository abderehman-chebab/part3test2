import scrapy
from edeka24.items import Edeka24Item


class Edeka24Spider(scrapy.Spider):
    name = "edeka24spider"
    start_urls = ["https://www.edeka24.de/Lebensmittel/Suess-Salzig/Schokoriegel/"]

    def parse(self, response):
        for product in response.css(".product-tile"):
            item = Edeka24Item()
            item['product_name'] = product.css(".product-tile-title::text").get()
            item['breadcrumb'] = response.css(".breadcrumb li a::text").getall()
            item['price'] = product.css(".price-current::text").get().strip()
            item['image_url'] = product.css("img.lazyautosizes::attr(src)").get()

            yield item

        # Pagination (if needed)
        next_page = response.css(".next a::attr(href)").get()
        if next_page is not None:
            yield response.follow(next_page, callback=self.parse)
